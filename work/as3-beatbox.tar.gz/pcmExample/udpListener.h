#ifndef _UDP_H_
#define _UDP_H_

#define MSG_MAX_LEN 1024
void start_udpThread(void);
void join_udpThread(void);

#endif